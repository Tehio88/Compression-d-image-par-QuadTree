#ifndef __bits__
#define __bits__

#include "quadtree.h"
#include <stdint.h> 

// Fonction pour écrire des bits dans un fichier
void pushbits(FILE *fichier, int *bit_count, uint8_t *buffer,int nb, int *bits_ecrits,int taille);

// Fonction pour lire les bits à partir d'un fichier et les assembler dans entier (nb)
void  pullbits(FILE *fichier, int *bit_count, uint8_t *buffer,int* nb, Cellule *tab, int taille);

#endif
