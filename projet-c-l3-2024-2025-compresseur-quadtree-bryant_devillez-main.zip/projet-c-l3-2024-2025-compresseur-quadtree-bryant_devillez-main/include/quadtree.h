#ifndef __quadtree__
#define __quadtree__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

typedef struct{
    int m;
    int e;
    int u;
    float v;
}Cellule;



// Retourne la taille totale du quadtree
int tailleracine(int tailleTab);

// Retourne l'index du fils (1 à 4) dans le quadtree.
int child(int index, int fils);

// Retourne l'index du parent dans le quadtree
int prof(int size);

// Calcule la profondeur maximale du quadtree
void remptab2(Cellule *tab, int index);

// Remplit le tableau de cellules (quadtree)
void codage(Cellule *tab, int index, int size);

// Définit un noeud du quadtree et ses fils à l'indice index avec des valeurs nulles
void codagenull(Cellule *tab, int index, int size);

// Réalise le codage du quadtree
void decodage(Cellule *tab, int index, int size);

// Réalise le décodage du quadtree
void calc_variances(Cellule * tab, int size, float * medvar, float * maxvar);

// Calcule la variance moyenne et maximale pour tous les noeuds non uniformes
int filtrage(Cellule * tab, int index, int size, float sigma, float alpha);

// Définit la valeur d’un noeud et tous ses fils avec une valeur par défaut (255)
void codagefiltrage(Cellule * tab, int size, float alpha);

// Réalise la grille de segmentation 
void codageSegm(Cellule *tab, int index, int size, int sizeRacine);

#endif