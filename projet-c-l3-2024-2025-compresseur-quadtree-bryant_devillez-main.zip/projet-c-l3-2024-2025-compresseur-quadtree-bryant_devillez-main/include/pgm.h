#ifndef __pgm__
#define __pgm__

#include "bits.h"
#include <math.h>
#include <time.h>
#include <getopt.h>

// Fonction pour lire un fichier PGM et remplir le quadtree
Cellule* readPGM(FILE *fichier, int *sizeTab);

// Fonction pour écrire un fichier PGM à partir du quadtree
void writePGM(FILE *fichier, Cellule *tab, int size, int index);

#endif