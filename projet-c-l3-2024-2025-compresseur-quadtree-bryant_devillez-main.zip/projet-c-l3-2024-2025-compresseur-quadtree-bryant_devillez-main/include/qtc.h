#ifndef __qtc__
#define __qtc__

#include "bits.h"
#include <math.h>
#include <time.h>
#include <getopt.h>


// Ecrit les pixels du quadtree dans un fichier
void enlevtab(Cellule *tab, int* index , int largeinit , int large, long posfichier, FILE *fichier);

// Cette fonction lit un fichier QTC et initialise le quadtree
void writeQTC(FILE *fichier, Cellule *tab, int size);

// Ecrit les données du quadtree dans un fichier QTC avec l'affichage du taux de compression
Cellule* readQTC(FILE *fichier, int *sizeTab);

#endif
