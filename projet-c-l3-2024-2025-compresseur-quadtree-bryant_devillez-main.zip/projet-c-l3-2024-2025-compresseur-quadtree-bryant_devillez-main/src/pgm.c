#include "../include/pgm.h"
#include "../include/qtc.h"


// Remplit le quadtree à partir des données présentes dans le fichier
void remptab(Cellule *tab, int* index,int largeinit, int large, long posfichier, FILE *fichier){
    if (large >= 2){
        remptab(tab, index, largeinit, large / 2, posfichier, fichier); //f1
        remptab(tab, index, largeinit, large / 2, posfichier + large / 2, fichier); //f2
        remptab(tab, index, largeinit ,large / 2, posfichier + (large / 2) + (large / 2) * largeinit, fichier); //f3
        remptab(tab, index, largeinit ,large / 2, posfichier + (large / 2) * largeinit, fichier); //f4
        return ;
    }
    fseek(fichier, posfichier ,SEEK_SET);
    unsigned char pixel;
    fread(&pixel, sizeof(unsigned char), 1, fichier);
    tab[*index].m = (int)pixel;
    tab[*index].e = 0;
    tab[*index].u = 1;
    (*index)++;
}

// Fonction pour lire un fichier PGM et remplir le quadtree
Cellule* readPGM(FILE *fichier, int *sizeTab) {
    char type[3];
    int width, height, max_val;
    fscanf(fichier, "%s\n", type);
    if (strcmp(type, "P5") != 0) {
        printf("Ce n'est pas un fichier PGM binaire.\n");
        return NULL;
    }
    while (1) {
        char ch = fgetc(fichier);
        if (ch == '#')
            while (fgetc(fichier) != '\n');
        else{
            ungetc(ch, fichier);
            break;
        }
    }
    fscanf(fichier, "%d %d", &width, &height);
    *sizeTab = width * height;
    fscanf(fichier, "%d", &max_val);
    int index = tailleracine(*sizeTab);
    Cellule *tab = malloc(sizeof(Cellule) * ((*sizeTab) + index));
    if (tab == NULL) {
        perror("Erreur d'allocation mémoire");
        return NULL;
    }
    unsigned char pixel;
    fread(&pixel, sizeof(unsigned char), 1, fichier);
    long base = ftell(fichier);
    remptab(tab,&index,width,width,base,fichier);
    remptab2(tab,tailleracine(*sizeTab));
    fclose(fichier);
    return tab;
}

// Fonction pour écrire un fichier PGM à partir du quadtree
void writePGM(FILE *fichier, Cellule *tab, int size, int index){
    fprintf(fichier, "P5\n");
    fprintf(fichier, "# date\n");
    fprintf(fichier, "%d %d\n", size, size);
    fprintf(fichier, "255\n");
    long base = ftell(fichier);
    enlevtab(tab, &index, size, size,base, fichier);
    fclose(fichier);
}