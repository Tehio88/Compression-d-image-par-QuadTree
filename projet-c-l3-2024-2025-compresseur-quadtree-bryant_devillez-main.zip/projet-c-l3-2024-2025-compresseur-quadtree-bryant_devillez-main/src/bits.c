#include "../include/bits.h"


// Fonction pour écrire des bits dans un fichier
void pushbits(FILE *fichier, int *bit_count, uint8_t *buffer,int nb, int *bits_ecrits,int taille){
    for (int j = 0; j < taille; j++) {
        if (taille == 8)
            *buffer |= ((nb << j) & 0x80) >> *bit_count;
        else if (taille == 2)
            *buffer |= (((nb << 6) << j) & 0x80) >> *bit_count;
        else if (taille == 1)
            *buffer |= (nb << 7) >> *bit_count;
        (*bit_count)++;
        (*bits_ecrits)++;
        
        if (*bit_count == 8) { // Réinitialisation du buffer et du compteur de bits
            fwrite(buffer, 1, 1, fichier);
            *buffer = 0;
            *bit_count = 0;
        }
    }
}

// Fonction pour lire les bits à partir d'un fichier et les assembler dans entier (nb)
void  pullbits(FILE *fichier, int *bit_count, uint8_t *buffer,int* nb, Cellule *tab, int taille){
    for (int j = 0; j < taille; j++) { //e
        if (*bit_count == 0) {
            if (fread(buffer, 1, 1, fichier) != 1) {
                perror("Erreur lors de la lecture des données");
                free(tab);
                fclose(fichier);
                exit(EXIT_FAILURE);
            }
        }
        if (taille == 8)
            *nb |= ((*buffer << *bit_count & 0x80) >> 7) << (7 - j);
        else if (taille == 2)
            *nb |= ((*buffer << *bit_count & 0x80) >> 7) << (1 - j);
        else if (taille == 1)
            *nb = (*buffer << *bit_count & 0x80) >> 7;
        
        (*bit_count)++; 
        if (*bit_count == 8) { // Réinitialisation du compteur de bits
            *bit_count = 0;
        }
    }       
}
