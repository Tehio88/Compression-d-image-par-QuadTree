#include "../include/qtc.h"

// Ecrit les pixels du quadtree dans un fichier
void enlevtab(Cellule *tab, int* index , int largeinit , int large, long posfichier, FILE *fichier){
    if (large >= 2){
        enlevtab(tab, index, largeinit, large / 2, posfichier, fichier); //f1
        enlevtab(tab, index, largeinit, large / 2, posfichier + large / 2, fichier); //f2
        enlevtab(tab, index, largeinit ,large / 2, posfichier + (large / 2) + (large / 2) * largeinit, fichier); //f3
        enlevtab(tab, index, largeinit ,large / 2, posfichier + (large / 2) * largeinit, fichier); //f4
        return ;
    }
    fseek(fichier, posfichier ,SEEK_SET);
    unsigned char pixel = tab[*index].m;
    fwrite(&pixel,sizeof(unsigned char), 1, fichier);
    (*index)++;
}

// Cette fonction lit un fichier QTC et initialise le quadtree
Cellule* readQTC(FILE *fichier, int *sizeTab){
    char type[3];
    int size;
    fscanf(fichier, "%s\n", type);
    if (strcmp(type, "Q1") != 0) {
        printf("Ce n'est pas un fichier QTC valide.\n");
        return NULL;
    }
    while (1) {
        char ch = fgetc(fichier);
        if (ch == '#')
            while (fgetc(fichier) != '\n');
        else{
            ungetc(ch, fichier);
            break;
        }
    }
    unsigned char pixel;
    fread(&pixel, sizeof(unsigned char), 1, fichier);
    *sizeTab = (int) pixel;
    *sizeTab = pow(pow(2,*sizeTab),2);
    size= *sizeTab + tailleracine(*sizeTab);
    Cellule *tab = malloc(sizeof(Cellule) * (size));
    if (tab == NULL) {
        perror("Erreur d'allocation mémoire");
        return NULL;
    }
    uint8_t buffer = 0;
    int bit_count = 0;
    for (int i = 0; i < size; i++) {
        if (tab[i].m != -1) tab[i].m = 0;
        if (tab[i].e != -1) tab[i].e = 0;
        if (tab[i].u != -1) tab[i].u = 0;
        if (tab[i].m != -1 && (i==0 || (i-1) % 4 != 3)){
            pullbits(fichier,&bit_count,&buffer,&tab[i].m,tab,8);
        }
        else 
            tab[i].m = -1;

        if (tab[i].e != -1 && child(i, 1) < size){
            pullbits(fichier,&bit_count,&buffer,&tab[i].e,tab,2);
        }
        else
            tab[i].e = -1;

        if (tab[i].u != -1 && tab[i].e == 0){
            pullbits(fichier,&bit_count,&buffer,&tab[i].u,tab,1);
            if (tab[i].u == 1){
                if (size >= child(i,1)){
                    for (int j = 1 ; j < 5 ; j++){
                        codagenull(tab,child(i,j),size);
                    }
                }
            }
        }
        else
            tab[i].u = -1;
    }
    fclose(fichier);
    return tab;
}

// Ecrit les données du quadtree dans un fichier QTC avec l'affichage du taux de compression
void writeQTC(FILE *fichier, Cellule *tab, int size) {
    char date_buffer[256];
    time_t now = time(NULL);
    struct tm *local_time = localtime(&now);
    strftime(date_buffer, sizeof(date_buffer), "# %a %b %d %H:%M:%S %Y", local_time);


    fprintf(fichier, "Q1\n");
    fprintf(fichier, "%s\n", date_buffer);
    long base = ftell(fichier); 
    fprintf(fichier, "#                          \n"); 


    uint8_t bufferprof = prof(size); 
    if (fwrite(&bufferprof, 1, 1, fichier) != 1) {
        perror("Erreur lors de l'écriture de la profondeur");
        fclose(fichier);
        return;
    }
    int bits_ecrits = 0;
    uint8_t buffer = 0;
    int bit_count = 0; 
    for (int i = 0; i < size; i++) {
        if (tab[i].m != -1) {
            pushbits(fichier,&bit_count,&buffer,tab[i].m,&bits_ecrits,8);
        }
        if (tab[i].e != -1) {
            pushbits(fichier,&bit_count,&buffer,tab[i].e,&bits_ecrits,2);
        }
        if (tab[i].u != -1) {
            pushbits(fichier,&bit_count,&buffer,tab[i].u,&bits_ecrits,1);
        }
    }

    if (bit_count != 0) {
        bits_ecrits += 8 - bit_count;
        fwrite(&buffer, 1, 1, fichier);
    }

    float taux_compression = (float)bits_ecrits / (pow(pow(2, prof(size)), 2) * 8) * 100.0;


    fseek(fichier, base, SEEK_SET);
    fprintf(fichier,"# compression rate %.2f%%",taux_compression);

    fclose(fichier);
}




