#include "../include/quadtree.h"

#define HD 11
#define HG 12
#define H 10
#define D 1
#define G 2
#define BD 21
#define BG 22
#define B 20


// Retourne la taille totale du quadtree
int tailleracine(int tailleTab){
    int tmp = tailleTab;
    int result = 0;
    while (tmp / 4 > 0)
    {
        result = result +  tmp / 4;
        tmp = tmp / 4;
    }
    return result;
}

// Retourne l'index du fils (1 à 4) dans le quadtree.
int child(int index, int fils){
    if (fils < 0 || fils > 4)
        return -1;
    return 4 * index + fils; 
}

// Retourne l'index du parent dans le quadtree
int father(int index) {
    if (index == 0)
        return -1;
    return (index - 1) / 4;
}

// Calcule la profondeur maximale du quadtree
int prof(int size){
    int index = 0;
    int result = 0;
    while(1){
        index = child(index, 1);
        if (index >= size)
            return result;
        result ++;
    }
    return result;
}

// Remplit le tableau de cellules (quadtree)
void remptab2(Cellule *tab, int index) {
    for (int i = index - 1; i >= 0; i--) {
        int m1 = tab[child(i, 1)].m;
        int m2 = tab[child(i, 2)].m;
        int m3 = tab[child(i, 3)].m;
        int m4 = tab[child(i, 4)].m;
        
        float v1 = tab[child(i, 1)].v;
        float v2 = tab[child(i, 2)].v;
        float v3 = tab[child(i, 3)].v;
        float v4 = tab[child(i, 4)].v;

        tab[i].m = (m1 + m2 + m3 + m4) / 4;
        tab[i].e = (m1 + m2 + m3 + m4) % 4;
        
        // Calcul de la variance
        float u = v1 * v1 + pow((tab[i].m - m1), 2) +
                  v2 * v2 + pow((tab[i].m - m2), 2) +
                  v3 * v3 + pow((tab[i].m - m3), 2) +
                  v4 * v4 + pow((tab[i].m - m4), 2);
        tab[i].v = sqrt(u) / 4.0;

        // Vérification de l'uniformité
        if (m1 == m2 && m2 == m3 && m3 == m4 &&
            tab[child(i, 1)].u == 1 && tab[child(i, 2)].u == 1 &&
            tab[child(i, 3)].u == 1 && tab[child(i, 4)].u == 1) {
            tab[i].u = 1;
        } else {
            tab[i].u = 0;
        }
    }
}

// Définit un noeud du quadtree et ses fils à l'indice index avec des valeurs nulles
void codagenull(Cellule *tab, int index, int size){
    if (index > size)
        return ;

    tab[index].m = -1;
    tab[index].u = -1;
    tab[index].e = -1;

    for (int i = 1 ; i < 5 ;i++){
        codagenull(tab,child(index,i),size);
    }
}

// Réalise le codage du quadtree
void codage(Cellule *tab, int index, int size){
    if (index > size)
        return ;

    if (child(index,1) >= size){
        tab[index].u = -1;
        tab[index].e = -1;
        return;
    }

    if (tab[index].e != 0)
        tab[index].u = -1;

    if (tab[index].u == 1){
        for (int i = 1 ; i < 5 ;i++){
            codagenull(tab,child(index,i),size);
        }
    }
    tab[child(index,4)].m = -1; 

    for (int i = 1 ; i < 5 ;i++){
        codage(tab,child(index,i),size);
    }
}

// Réalise le décodage du quadtree
void decodage(Cellule *tab, int index, int size){
    if (index > size)
        return;
    

    if (tab[index].m == -1){          //uniforme
        tab[index].m = tab[father(index)].m;
        tab[index].u = 1;
        tab[index].e = 0;
    }

    if (tab[index].e == -1)
        tab[index].e = 0;

    if (child(index,4) < size && tab[index].u != 1){  //creation 4 fils
        int tmp = 0;
        for(int i = 1; i < 4; i++){
            tmp+= tab[child(index, i)].m;
        }
        tab[child(index,4)].m = (4 * tab[index].m + tab[index].e) - tmp;
    }

    if (tab[index].u == -1){
        if (child(index , 1 ) >= size)
            tab[index].u = 1;
        else
            tab[index].u = 0;
    }
    
    for (int i = 1 ; i < 5 ;i++){
        decodage(tab,child(index,i),size);
    }

}

// Calcule la variance moyenne et maximale pour tous les noeuds non uniformes
void calc_variances(Cellule * tab, int size, float * medvar, float * maxvar) {
    float moyenne_variance_total = 0.0;
    float max = 0.0;
    int cmpt_non_uniforme = 0;

    for(int i = 0; i < size; i++) {
        if(child(i, 1) >= size) continue; // On exclut les feuilles dans le calcul

        else if(tab[i].u != -1) { // Noeuds non uniformes
            moyenne_variance_total += tab[i].v;
            if(tab[i].v > max) max = tab[i].v;
            cmpt_non_uniforme++;
        }
    }   
    *medvar = moyenne_variance_total / cmpt_non_uniforme;
    *maxvar = max;
}

// Réalise le filtrage d'un quadtree
int filtrage(Cellule * tab, int index, int size, float sigma, float alpha) {

    if(tab[index].u == 1) return 1;
    if(child(index , 1 ) >= size) return 1;

    int s = 0;
    for (int i = 1; i < 5; ++i)
        s += filtrage(tab, child(index, i), size, sigma * alpha, alpha);
        
    if(s < 4 || tab[index].v > sigma) return 0;
    tab[index].e = 0;
    tab[index].u = 1;
    return 1;
}

// Définit la valeur d’un noeud et tous ses fils avec une valeur par défaut (255)
void codagenullSegm(Cellule *tab, int index, int size){
    if (index > size)
        return ;

    tab[index].m = 255;
    for (int i = 1 ; i < 5 ;i++){
        codagenullSegm(tab,child(index,i),size);
    }
}

// Edite les bords de la grille de segmentation
void codagenullSegmBord(Cellule *tab, int index, int size, int bord){
    if (index > size)
        return ;
    
    if(bord == HG){
        codagenullSegmBord(tab,child(index,1),size,HG);
        codagenullSegmBord(tab,child(index,2),size,H);
        codagenullSegm(tab,child(index,3),size);
        codagenullSegmBord(tab,child(index,4),size,G);
    }else if (bord == HD){
        codagenullSegmBord(tab,child(index,1),size,H);
        codagenullSegmBord(tab,child(index,2),size,HD);
        codagenullSegmBord(tab,child(index,3),size,D);
        codagenullSegm(tab,child(index,4),size);
    }else if (bord == H){
        codagenullSegmBord(tab,child(index,1),size,H);
        codagenullSegmBord(tab,child(index,2),size,H);
        codagenullSegm(tab,child(index,3),size);
        codagenullSegm(tab,child(index,4),size);
    }else if(bord == G){
        codagenullSegmBord(tab,child(index,1),size,G);
        codagenullSegm(tab,child(index,2),size);
        codagenullSegm(tab,child(index,3),size);
        codagenullSegmBord(tab,child(index,4),size,G);
    }else if (bord == D){
        codagenullSegm(tab,child(index,1),size);
        codagenullSegmBord(tab,child(index,2),size,D);
        codagenullSegmBord(tab,child(index,3),size,D);
        codagenullSegm(tab,child(index,4),size);
    }else if (bord == BG){
        codagenullSegmBord(tab,child(index,1),size,G);
        codagenullSegm(tab,child(index,2),size);
        codagenullSegmBord(tab,child(index,3),size,B);
        codagenullSegmBord(tab,child(index,4),size,BG);
    }else if (bord == BD){
        codagenullSegm(tab,child(index,1),size);
        codagenullSegmBord(tab,child(index,2),size,D);
        codagenullSegmBord(tab,child(index,3),size,BD);
        codagenullSegmBord(tab,child(index,4),size,B);
    }else if (bord == B){
        codagenullSegm(tab,child(index,1),size);
        codagenullSegm(tab,child(index,2),size);
        codagenullSegmBord(tab,child(index,3),size,B);
        codagenullSegmBord(tab,child(index,4),size,B);
    }
    tab[index].m = 0;
}


// Réalise la grille de segmentation 
void codageSegm(Cellule *tab, int index, int size, int sizeRacine){
    if (index > size)
        return ;

    if (tab[index].u == 1 && index < sizeRacine){
        if (prof(index) > 2){
            codagenullSegmBord(tab,child(index,1),size,HG);
            codagenullSegmBord(tab,child(index,2),size,HD);
            codagenullSegmBord(tab,child(index,3),size,BD);
            codagenullSegmBord(tab,child(index,4),size,BG);
        }
        else{
            for (int i = 1 ; i < 5 ;i++){
                codagenullSegm(tab,child(index,i),size);
            }
        }
    }
    else {
        tab[index].m = 150;
        for (int i = 1 ; i < 5 ;i++){
            codageSegm(tab,child(index,i),size,sizeRacine);
        }
    }
}